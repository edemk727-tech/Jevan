# JEVAN — Flutter starter

This is the initial Android app foundation for JEVAN. It includes:
- JEVAN branding and a four-tab starter interface
- Firebase phone-number sign-in / SMS OTP flow
- Placeholder screens for Chats, Updates, Calls and Settings

This is **not yet a production messaging app**. Real-time chat, group membership,
media upload, voice notes, calling, push notifications, moderation, account
deletion, privacy controls and production security rules still need to be built
and tested.

## Requirements
- Flutter SDK (stable)
- Android Studio and Android SDK
- A Firebase project
- A physical Android phone for OTP and call testing

## Setup
1. Install Flutter and Android Studio.
2. Create a Firebase project at https://console.firebase.google.com/.
3. Add an Android app to Firebase. Use your final application ID, for example
   `com.yourcompany.jevan` (choose and confirm this before release).
4. Enable **Phone** under Firebase Authentication > Sign-in method.
5. Install FlutterFire CLI and configure the project:
   - `dart pub global activate flutterfire_cli`
   - `flutterfire configure`
   This generates `lib/firebase_options.dart`.
6. Update `main.dart` to initialize Firebase with generated options:
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
   and add `import 'firebase_options.dart';`
7. Run:
   - `flutter pub get`
   - `flutter run`

## Important before launch
- Configure Firebase App Check, SMS regions, quotas and billing as required.
- Test OTP delivery in Ghana and on supported devices.
- Replace the deny-all Firestore rules only after designing and reviewing
  secure per-user and per-chat membership rules.
- Implement end-to-end encryption if JEVAN will promise it. Do not claim
  end-to-end encryption until the protocol is implemented and independently
  reviewed.
- Add a privacy policy, terms, account deletion, data safety disclosures,
  content reporting/blocking and Google Play testing/release requirements.
- Use a calling provider / WebRTC implementation with proper TURN infrastructure.
- Never commit Firebase service-account keys or private credentials.

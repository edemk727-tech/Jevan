import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

const jevanGreen = Color(0xFF075E54);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const JevanApp());
}

class JevanApp extends StatelessWidget {
  const JevanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JEVAN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: jevanGreen),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
        appBarTheme: const AppBarTheme(
          backgroundColor: jevanGreen,
          foregroundColor: Colors.white,
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const PhoneLoginPage() : const JevanHome();
      },
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});

  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phoneController = TextEditingController(text: '+233');
  final codeController = TextEditingController();
  String? verificationId;
  bool sending = false;
  String message = '';

  Future<void> sendCode() async {
    final phone = phoneController.text.trim();
    if (phone.length < 8) {
      setState(() => message = 'Enter a valid phone number with country code.');
      return;
    }
    setState(() { sending = true; message = ''; });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (error) {
        if (mounted) setState(() { sending = false; message = error.message ?? 'Verification failed.'; });
      },
      codeSent: (id, resendToken) {
        if (mounted) setState(() { verificationId = id; sending = false; message = 'Code sent. Check your SMS.'; });
      },
      codeAutoRetrievalTimeout: (id) {
        verificationId = id;
      },
    );
  }

  Future<void> verifyCode() async {
    final id = verificationId;
    if (id == null) return;
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: id,
        smsCode: codeController.text.trim(),
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => message = e.message ?? 'Could not verify that code.');
    }
  }

  @override
  void dispose() {
    phoneController.dispose();
    codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const CircleAvatar(
                    radius: 38,
                    backgroundColor: jevanGreen,
                    child: Icon(Icons.forum_rounded, color: Colors.white, size: 38),
                  ),
                  const SizedBox(height: 18),
                  const Text('JEVAN', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: jevanGreen)),
                  const Text('Connect. Chat. Share.', textAlign: TextAlign.center),
                  const SizedBox(height: 36),
                  const Text('Sign in with your phone number',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone number',
                      hintText: '+233 XX XXX XXXX',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (verificationId != null)
                    TextField(
                      controller: codeController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'SMS verification code',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: sending ? null : (verificationId == null ? sendCode : verifyCode),
                    style: FilledButton.styleFrom(backgroundColor: jevanGreen, padding: const EdgeInsets.all(16)),
                    child: Text(sending ? 'Sending…' : (verificationId == null ? 'Send verification code' : 'Verify and continue')),
                  ),
                  if (message.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(message, textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 18),
                  const Text('By continuing, you agree to JEVAN’s Terms and Privacy Policy.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class JevanHome extends StatefulWidget {
  const JevanHome({super.key});

  @override
  State<JevanHome> createState() => _JevanHomeState();
}

class _JevanHomeState extends State<JevanHome> {
  int selected = 0;
  final pages = const [ChatsPage(), UpdatesPage(), CallsPage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('JEVAN', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert)),
        ],
      ),
      body: pages[selected],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (index) => setState(() => selected = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.circle_outlined), label: 'Updates'),
          NavigationDestination(icon: Icon(Icons.call_outlined), label: 'Calls'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ChatTile(initial: 'K', name: 'Kwame', preview: 'Welcome to JEVAN!', time: 'Now'),
        ChatTile(initial: 'A', name: 'Ama', preview: 'Your messages will appear here.', time: ''),
        ChatTile(initial: 'J', name: 'JEVAN Community', preview: 'Create your first group chat.', time: ''),
        Padding(
          padding: EdgeInsets.all(24),
          child: Text('Your real conversations will appear here after chat and contact services are connected.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        ),
      ],
    );
  }
}

class ChatTile extends StatelessWidget {
  final String initial, name, preview, time;
  const ChatTile({super.key, required this.initial, required this.name, required this.preview, required this.time});
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFFD8EEE8),
        child: Text(initial, style: const TextStyle(color: jevanGreen, fontWeight: FontWeight.bold))),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(preview),
      trailing: Text(time, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      onTap: () {},
    );
  }
}

class UpdatesPage extends StatelessWidget {
  const UpdatesPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('JEVAN Updates\nStatus sharing will be added here.', textAlign: TextAlign.center));
}
class CallsPage extends StatelessWidget {
  const CallsPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Text('JEVAN Calls\nVoice and video calling will be added here.', textAlign: TextAlign.center));
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
    const ListTile(leading: Icon(Icons.person_outline), title: Text('Profile')),
    const ListTile(leading: Icon(Icons.lock_outline), title: Text('Privacy and security')),
    const ListTile(leading: Icon(Icons.notifications_outlined), title: Text('Notifications')),
    ListTile(
      leading: const Icon(Icons.logout),
      title: const Text('Sign out'),
      onTap: () => FirebaseAuth.instance.signOut(),
    ),
  ]);
}
